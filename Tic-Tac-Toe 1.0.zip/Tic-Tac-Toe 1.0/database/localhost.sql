-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 04, 2024 at 05:06 PM
-- Server version: 10.5.20-MariaDB
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id22291571_login`
--
CREATE DATABASE IF NOT EXISTS `id22291571_login` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `id22291571_login`;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `fullname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`fullname`, `email`, `password`) VALUES
('Yathnesh Kasukurthi', 'yathneshk@gmail.com', '754410c136'),
('KPRAO', 'RAO@GMAIL.COM', '$2y$10$DtE/6BTOVEzO76qn0PhVpu5RIA8Oxk04kBv0x72kPMfnZ8RAI.SnS'),
('rao', 'rao@bakhresa.com', '$2y$10$m3WdhFZpG9clImjXAmeEkeedFVzVosAy7DrBuogifnU.a7OtMTKqi'),
('Yathnesh Kasukurthi', 'yathnesh.22bce20350@vitapstudent.ac.in', '$2y$10$6P1gbZNqkk7FyVvpkluFXObpVRiVV.vH4.Fv8qnkhmT433n7vUZF6'),
('Shahid', 'shaik182004@gmail.com', '$2y$10$Q2egKPLElpSPGU4U3l3Bn.N6a4IY55fpbVK4WJxfIYrhh8KxBqRJ.'),
('Sana', 'sanjana30113@gmail.com', '$2y$10$HhMuPwiKYT0rMUc6995mH.ic0XMPsq/e43EaFCVd6KW147qIw0zPi'),
('M.Jishnu namaste ', 'makineni.jishnu@gmail.com', '$2y$10$Gu0YWXs7nztPUH1kIt5JdueYm3Pa0NWP3huJQn7biK2VIBkoHTZL2');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
